
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL, , 'Alergolog�a');
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL, 'Anestesiolog�a');
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL,  'Cardiolog�a');
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL, 'Dermatolog�a');
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL, 'Endocrinolog�a');
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL, 'Gastroenterolog�a');
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL, 'Geriatr�a');
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL, 'Ginecolog�a');
INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES (NULL, 'Hemoterapia');
INSERT INTO `especialidad` (`ID`,  `NOMBRE`) VALUES (NULL, 'Infectolog�a');
