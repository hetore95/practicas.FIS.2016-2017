-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-05-2017 a las 14:13:12
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `clinica_upm`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cita`
--

CREATE TABLE `cita` (
  `ID` int(11) NOT NULL,
  `FECHA` datetime NOT NULL,
  `ID_ESPECIALIDAD` int(11) NOT NULL,
  `ID_PERSONAL` int(11) NOT NULL,
  `ID_PACIENTE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `cita`
--

INSERT INTO `cita` (`ID`, `FECHA`, `ID_ESPECIALIDAD`, `ID_PERSONAL`, `ID_PACIENTE`) VALUES
(8, '2017-05-25 08:00:00', 1, 2, 2),
(9, '2017-05-26 00:00:00', 1, 2, 2),
(10, '2017-05-12 00:00:00', 4, 1, 2),
(11, '2017-05-09 00:00:00', 3, 3, 2),
(12, '2017-05-01 00:00:00', 3, 3, 2),
(13, '2017-05-18 00:00:00', 3, 3, 2),
(14, '2017-05-03 00:00:00', 2, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidad`
--

CREATE TABLE `especialidad` (
  `ID` int(11) NOT NULL,
  `NOMBRE` varchar(20) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `especialidad`
--

INSERT INTO `especialidad` (`ID`, `NOMBRE`) VALUES
(1, 'Anestesiología'),
(2, 'Cardiología'),
(3, 'Dermatología'),
(4, 'Endocrinología'),
(5, 'Gastroenterología'),
(6, 'Geriatría'),
(7, 'Ginecología'),
(8, 'Hemoterapia'),
(9, 'Infectología'),
(10, 'Alergología');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial`
--

CREATE TABLE `historial` (
  `ID` int(11) NOT NULL,
  `ID_PACIENTE` int(11) NOT NULL,
  `ID_PERSONAL` int(11) NOT NULL,
  `F_ALTA` date NOT NULL,
  `F_ULT_MOD` date NOT NULL,
  `COMENTARIOS` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE `paciente` (
  `ID` int(11) NOT NULL,
  `ID_USUARIO` int(11) NOT NULL,
  `COMPANIA_SEGURO` varchar(15) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `paciente`
--

INSERT INTO `paciente` (`ID`, `ID_USUARIO`, `COMPANIA_SEGURO`) VALUES
(2, 4, 'Mufasa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal`
--

CREATE TABLE `personal` (
  `ID` int(11) NOT NULL,
  `ID_USUARIO` int(11) NOT NULL,
  `NUM_COLEGIADO` int(11) NOT NULL,
  `DISPONIBILIDAD` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `TIEMPO_MIN_CONSULTA` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `personal`
--

INSERT INTO `personal` (`ID`, `ID_USUARIO`, `NUM_COLEGIADO`, `DISPONIBILIDAD`, `TIEMPO_MIN_CONSULTA`) VALUES
(1, 2, 0, 'NO', 15),
(2, 5, 13123, 'NO', 20),
(3, 6, 123, 'NO', 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `programacion_salas`
--

CREATE TABLE `programacion_salas` (
  `ID` int(11) NOT NULL,
  `ID_SALA` int(11) NOT NULL,
  `ID_ESPECIALIDAD` int(11) NOT NULL,
  `ID_PERSONAL` int(11) NOT NULL,
  `FECHA` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `programacion_salas`
--

INSERT INTO `programacion_salas` (`ID`, `ID_SALA`, `ID_ESPECIALIDAD`, `ID_PERSONAL`, `FECHA`) VALUES
(842, 1, 1, 2, '2017-05-25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rel_personal_especialidad`
--

CREATE TABLE `rel_personal_especialidad` (
  `ID` int(11) NOT NULL,
  `ID_PERSONAL` int(11) NOT NULL,
  `ID_ESPECIALIDAD` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `rel_personal_especialidad`
--

INSERT INTO `rel_personal_especialidad` (`ID`, `ID_PERSONAL`, `ID_ESPECIALIDAD`) VALUES
(1, 1, 1),
(2, 1, 10),
(3, 1, 3),
(4, 2, 1),
(5, 2, 8),
(6, 2, 4),
(7, 3, 1),
(8, 3, 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `ID` int(10) UNSIGNED NOT NULL,
  `NOMBRE` varchar(16) COLLATE utf8_spanish_ci NOT NULL,
  `APELLIDOS` varchar(24) COLLATE utf8_spanish_ci NOT NULL,
  `DNI` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `PASSWORD` varchar(24) COLLATE utf8_spanish_ci NOT NULL,
  `TIPO_USUARIO` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID`, `NOMBRE`, `APELLIDOS`, `DNI`, `PASSWORD`, `TIPO_USUARIO`) VALUES
(1, 'ROOT', '', 'ROOT', 'ROOT', 'PERSONAL'),
(2, 'Fulanito', 'de Tal', '123456789', 'lololo', 'PERSONAL'),
(4, 'Francisco', 'Alegre y Olé', '12345678A', '', 'PACIENTE'),
(5, 'Lola', 'Flores', '12345678B', 'lololo', 'PERSONAL'),
(6, 'Sergio', 'Ramos', '12345678C', 'lololo', 'PERSONAL');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cita`
--
ALTER TABLE `cita`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_ESPECIALIDAD` (`ID_ESPECIALIDAD`),
  ADD KEY `ID_PERSONAL` (`ID_PERSONAL`),
  ADD KEY `ID_PACIENTE` (`ID_PACIENTE`);

--
-- Indices de la tabla `especialidad`
--
ALTER TABLE `especialidad`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `historial`
--
ALTER TABLE `historial`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_PACIENTE` (`ID_PACIENTE`),
  ADD KEY `ID_PERSONAL` (`ID_PERSONAL`);

--
-- Indices de la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_USUARIO` (`ID_USUARIO`);

--
-- Indices de la tabla `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_USUARIO` (`ID_USUARIO`);

--
-- Indices de la tabla `programacion_salas`
--
ALTER TABLE `programacion_salas`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_PERSONAL_2` (`ID_PERSONAL`),
  ADD KEY `ID_ESPECIALIDAD` (`ID_ESPECIALIDAD`) USING BTREE,
  ADD KEY `ID_PERSONAL` (`ID_PERSONAL`) USING BTREE;

--
-- Indices de la tabla `rel_personal_especialidad`
--
ALTER TABLE `rel_personal_especialidad`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_PERSONAL` (`ID_PERSONAL`),
  ADD KEY `ID_ESPECIALIDAD` (`ID_ESPECIALIDAD`) USING BTREE;

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cita`
--
ALTER TABLE `cita`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `especialidad`
--
ALTER TABLE `especialidad`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `historial`
--
ALTER TABLE `historial`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `paciente`
--
ALTER TABLE `paciente`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `personal`
--
ALTER TABLE `personal`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `programacion_salas`
--
ALTER TABLE `programacion_salas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=843;
--
-- AUTO_INCREMENT de la tabla `rel_personal_especialidad`
--
ALTER TABLE `rel_personal_especialidad`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `programacion_salas`
--
ALTER TABLE `programacion_salas`
  ADD CONSTRAINT `programacion_salas_ibfk_1` FOREIGN KEY (`ID_ESPECIALIDAD`) REFERENCES `especialidad` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `programacion_salas_ibfk_2` FOREIGN KEY (`ID_PERSONAL`) REFERENCES `personal` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
