/**
 * borrarCalendario -  elimina el calendario presente en la página
 */
function borrarCalendario() {
	$('#calendario').empty();
	$('#error_calendario').hide('slow');
}

/**
 * cargarCalendario - solicita al servidor el calendario de citas del día para el médico conectado
 */
function cargarCalendario() {
	var peticion = {'accion': 'consultar', 'opcion': 'calendarioDiario'};
	var respuesta = {};

	$('#error_calendario').hide();
	$('#error_calendario').removeClass('alert-info');
	$('#error_calendario').removeClass('alert-danger');
	
	//SOLICITAR DATOS
	respuesta = enviarJSON('../php/calendario.php', peticion);

	respuesta.done(function (data, textStatus, jqXHR) {

		if (data.error) {
			$('#error_calendario').addClass('alert-danger');

			$('#error_calendario > span').text(data.descripcion);
			$('#error_calendario').show('slow');
			
		} else if(data.citas.length == 0) {
			$('#error_calendario').addClass('alert-info');

			$('#error_calendario > span').text("No tiene citas concertadas para hoy.");
			$('#error_calendario').show('slow');
			
		} else {
			//CARGAR DATOS
			$("#calendario").append('<div class="col-md-12"><div class="card"><div class="header"><h4 class="title">Citas programadas.</h4><p class="category">Dr. '+data.medico+' para el día '+data.dia+' tiene las siguientes citas:</p></div><div class="content table-responsive table-full-width"><table class="table table-hover table-striped"><thead><th>Hora</th><th>Paciente</th><th>Opción</th></thead><tbody id="dia">');
				
			for (i = 0; i < data.citas.length; i++) {
				$dia = data.citas[i].fecha;

				$hora = (data.citas[i].hora).split('.')[0] + ':' + (data.citas[i].hora).split('.')[1];
				$("#dia").append('<tr><td>' + $hora + '</td><td>' + data.citas[i].paciente + '</td><td style="vertical-align:middle"><a href="historial.html?paciente='+data.citas[i].idPaciente+'&medico='+data.idMedico+'"><i class="fa pe-7s-box1" style="font-size:1em"></i> Historial</a></td></tr>');
			}
			$("#calendario").append('</tbody></table></div></div></div</div></div>');
			$('h4.title').css('color', 'purple');
			$('h4.title').css('border-bottom', '1px solid');
		}

	});
}