$( document ).ready(function() {

    pintarMenu('estadisticas','salmon');
    pintarBarraNavegacion();

    cargarEspecialidad();

    $("#listaEspecialidades").change(function () {
		//Limpiar alerta
		$('#no_especialidad_canvas').hide();
    	// Limpiar canvas
    	$('#anualNivelTrabajo').remove();
    	// Generar canvas
    	$('#contenedorCanvasBarras').html('<canvas id="anualNivelTrabajo" width="auto" height="70"></canvas>');
    	generarGraficoNivelTrabajo($('#anualNivelTrabajo'), generarFechaActual());
    });

    $('#contenedorCanvasQueso').html('<canvas id="graficoEspecialidad" width="auto" height="70"></canvas>');
    generarGraficoEspecialidad($('#graficoEspecialidad'));
    $('#fechaQueso').html( generarFechaActual() );
});

function generarFechaActual() {

	var currentdate = new Date();
	var datetime = '<i class="fa fa-clock-o"></i> '
				+ "Generado: " + ("0"+currentdate.getDate()).slice(-2) + "/"
                + (("0"+(currentdate.getMonth()+1))).slice(-2)  + "/" 
                + currentdate.getFullYear() + " &nbsp; "  
                + ("0"+currentdate.getHours()).slice(-2) + ":"  
                + ("0"+currentdate.getMinutes()).slice(-2) + ":" 
                + ("0"+currentdate.getSeconds()).slice(-2);

    return datetime;
}

function cargarPaletaColores() {

	var paletaColores = [];

	paletaColores.push({color : 'Red', 		backgroundColor : 'rgba(210, 78, 91, 0.2)', 	borderColor : 'rgba(210, 78, 91, 1)'});
	paletaColores.push({color : 'Blue', 	backgroundColor : 'rgba(54, 162, 235, 0.2)', 	borderColor : 'rgba(54, 162, 235, 1)'});
	paletaColores.push({color : 'Yellow', 	backgroundColor : 'rgba(255, 206, 86, 0.2)', 	borderColor : 'rgba(255, 206, 86, 1)'});
	paletaColores.push({color : 'Green', 	backgroundColor : 'rgba(75, 192, 192, 0.2)',	borderColor : 'rgba(75, 192, 192, 1)'});
	paletaColores.push({color : 'Purple', 	backgroundColor : 'rgba(153, 102, 255, 0.2)', 	borderColor : 'rgba(153, 102, 255, 1)'});
	paletaColores.push({color : 'Orange', 	backgroundColor : 'rgba(255, 159, 64, 0.2)', 	borderColor : 'rgba(255, 159, 64, 1)'});
	paletaColores.push({color : 'Pink', 	backgroundColor : 'rgba(252, 129, 194, 0.2)', 	borderColor : 'rgba(252, 129, 194, 1)'});

	return paletaColores;
}

/**
 * generarColoresGrafico - genera un array de colores aleatorios según el número de series que se le
 						   pase por parámetro
 */

function generarColoresGrafico( numeroSeries ) {

	var coloresGrafico = [];

	var paletaColores = cargarPaletaColores();

	/*var rgb = [];

	for(var i=0; i<arr_series.length; i++) {

		for(var j=0; j<3; j++)
			rgb[j] = Math.floor(Math.random() * 256);

		coloresGrafico[i] = {backgroundColors : 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ', 0.2)', borderColors[i] : 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ', 1)'};
	}*/

	for(var i=0; i<numeroSeries; i++) {

		coloresGrafico[i] = {backgroundColors : paletaColores[i].backgroundColor, borderColors : paletaColores[i].borderColor};  	
	}

	return coloresGrafico;
}

// Devuelve un array con todas las series que se quieren pintar

function generarGraficoNivelTrabajo( objCanvas, datetime ){

	var peticion = {};
	var especialidad = $( "#listaEspecialidades option:selected" ).text();

	peticion.accion = 'consultar';
	peticion.opcion = 'grafico';
	peticion.tipo_grafico = 'barras';
	peticion.especialidad = especialidad;

	var respuesta = enviarJSON('../php/insertarPersonal.php', peticion);

    respuesta.done(function( data, textStatus, jqXHR ) {

    	var colores = generarColoresGrafico(data.length);
    	var arr_datos_eje_x = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    	var arr_serie = [];

    	$.each( data, function( key, value ) {

            arr_serie.push({label : value.nombre, 
            				data : value.num_citas,
            				backgroundColor : colores[key].backgroundColors,
				            borderColor : colores[key].borderColors,
				            borderWidth : 1 });
        });

    	// Si la especialidad no tiene citas ni profesionales
    	if( arr_serie.length == 0 ){

    		$('#fechaBarras').empty();

    		$('#no_especialidad_canvas > span').text('No hay datos de esa especialidad.');
        	$('#no_especialidad_canvas').show('slow');

    	} else {

    		var graficoBarras = new Chart( objCanvas, {
			    type: 'bar',
			    data: {
			        labels: arr_datos_eje_x,
			        datasets: arr_serie
			    },
			    options: {
			        scales: {
			            yAxes: [{
			                ticks: {
			                    beginAtZero:true
			                }
			            }]
			        }
			    }
			});

			// Pongo la fecha en la que se ha generado
  			$('#fechaBarras').html( datetime );
    	}

    });
}


function generarGraficoEspecialidad( objCanvas ){

	var peticion = {};

	peticion.accion = 'consultar';
	peticion.opcion = 'grafico';
	peticion.tipo_grafico = 'queso';

	var respuesta = enviarJSON('../php/insertarPersonal.php', peticion);

    respuesta.done(function( data, textStatus, jqXHR ) {

    	var colores = generarColoresGrafico(data.length);
    	var arr_dataset = [];
    	var arr_labels = [];
    	var arr_data = [];
    	var arr_backgroundColors = [];
    	var arr_hoverBackgroundColors = [];

    	$.each( data, function( key, value ) {

    		arr_labels[key] = value.especialidad;
            arr_data[key]   = value.num_citas;
            arr_backgroundColors[key] = colores[key].borderColors;
            arr_hoverBackgroundColors[key] = colores[key].backgroundColors;
        });

    	arr_dataset.push({data : arr_data, backgroundColor : arr_backgroundColors, hoverBackgroundColor : arr_hoverBackgroundColors});

    	var graficoQueso = new Chart( objCanvas, {
			    type: 'pie',
			    data: {
			        labels: arr_labels,
			        datasets: arr_dataset
			    },
			    options: {
			        animation:{
			            animateScale:true
			        }
			    }
		});
    });
}