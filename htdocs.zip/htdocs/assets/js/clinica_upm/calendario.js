/**
* cargarEspecialidad - consulta en la BD las posibles especialidades.
*/
function cargarEspecialidad() {

var respuesta = {};
var peticion = {};
var html = '';

peticion.accion = "consultar";
peticion.opcion = "especialidades";

respuesta = enviarJSON('../php/calendario.php', peticion);

respuesta.done(function (data, textStatus, jqXHR) {

html += '<option value="">Selecionar ...</option>';
if (data.error) {
	$('#error_calendario').addClass('alert-danger');
	$('#error_calendario > span').text(data.descripcion);
	$('#error_calendario').show('slow');
} else {
	$.each(data.especialidades, function (key, value) {
		$('#selectEspecialidad').append('<option value="' + value.ID + '">' + value.NOMBRE + '</option>');
	});
}
});
}
/**
* borrarCalendario -  elimina el calendario presente en la página
*/
function borrarCalendario() {
$('#calendario').empty();
$('#error_calendario').hide('slow');
}

/**
* cargarCalendario - solicita al servidor el calendario de citas de la semana en curso y lo muestra
*/
function cargarCalendario(esp) {
var peticion = {'accion': 'consultar', 'opcion': 'citas', 'id': esp};
var respuesta = {};

//SOLICITAR DATOS
respuesta = enviarJSON('../php/calendario.php', peticion);

respuesta.done(function (data, textStatus, jqXHR) {

if (data.error) {
	$('#error_calendario').addClass('alert-danger');

	$('#error_calendario > span').text(data.descripcion);
	$('#error_calendario').show('slow');
} else {
	//CARGAR DATOS
	$diaAnterior = 0;
	$j = 0;
	for (i = 0; i < data.citas.length; i++) {
		$dia = data.citas[i].fecha;

		//Si es un día nuevo, añadir nueva tabla
		if ($dia != $diaAnterior) {
			$j++;
			$diaAnterior = $dia;
			if ($j != 0) {
				$("#calendario").append('</tbody></table></div></div</div></div>');
			}
			$fecha = data.citas[i].fecha.split('.');
			$fecha = $fecha[0] + '/' + $fecha[1] + '/' + $fecha[2];
			$("#calendario").append('<div class="col-md-12"><div class="card"><div class="header"><table class="table table-border"><thead><tr><th>Fecha</th><th>Especialidad</th><th>Doctor</th><th>Sala</th></thead><tbody><tr><td><b>'  + $fecha + '</b></td><td>'+ data.especialidad+'</td><td>' + data.citas[i].medico+'</td><td>' +data.citas[i].sala + '</td></tbody></table></div><div class="header"><h4 class="title" style="border-bottom:1px solid purple;color:purple;">Citas concertadas</h4></div><table class="table table-striped"><thead><th>Hora</th><th>Paciente</th></thead><tbody id="dia' + $j + '">');
		}

		$hora = (data.citas[i].hora).split('.')[0] + ':' + (data.citas[i].hora).split('.')[1];
		$("#dia" + $j).append('<tr><td>' + $hora + '</td><td>' + data.citas[i].paciente + '</td></tr>');
	}
	$("#calendario").append('</tbody></table></div></div</div></div>');
}

});
}