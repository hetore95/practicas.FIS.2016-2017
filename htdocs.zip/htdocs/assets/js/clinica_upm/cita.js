
/*funcion cargarHoras, obtiene las horas disponibles del d�a y la especialidad
*indicadas y las carga en el formulario.
*/
function cargarHoras(){
    var peticion={};
    var respuesta={};
	
	//Borrar datos
	$('#nuevaCita_sala').val('');
	$('#nuevaCita_doctor').val('');
	$('#nuevaCita_hora').empty();
	$('#error_calendario').hide();

	
	//Petici�n
    peticion.accion = 'pedirHoras';
    peticion.especialidad =  $("#nuevaCita_especialidad").val();
    peticion.fecha = $("#datetimepicker2").val();

    console.log(peticion);

    respuesta=enviarJSON('../php/insertarCita.php',peticion); 

    respuesta.done(function(data,textStatus,jqXHR){

        if(data.error)  {
			
            $('#error_calendario').removeClass('alert-success');
            $('#error_calendario').addClass('alert-danger');
			$('#error_calendario > span').text(data.descripcion);
			$('#error_calendario').show('slow');
			
        } else {
			//Mostrar Doctor y Sala
			$('#nuevaCita_sala').val(data.sala);
			$('#nuevaCita_doctor').val(data.medico);
			
			//Agregar horas
             $('#nuevaCita_hora').empty();
             for (i = 8; i < 20; i++) {
                for(j = 0; j<60;j=j+parseInt(data.tiempoConsulta)){
					var encontrado = false;
					var k = 0;
					while(!encontrado && k < data.horas.length){
						if(data.horas[k] == ("0"+i).slice(-2)+'.'+("0"+j).slice(-2)+".00"){
							encontrado = true;
						}
						k++;
					}
					if(!encontrado){
						$opcion = '<option value="'+("0"+i).slice(-2)+':'+("0"+j).slice(-2)+':00">'+("0"+i).slice(-2)+':'+("0"+j).slice(-2)+'</option>';
						$('#nuevaCita_hora').append($opcion);
					}
              }
            }
        }
    });
}


/*funcion disponibilidadNuevaCita, obtener los datos del formulario de citas y los 
*envia a <fichero PHP>
*/
function disponibilidadNuevaCita(){
    var cita={};
    var respuesta={};
    
    cita.especialidad = $("#nuevaCita_especialidad").val();    
    cita.fecha = $("#datetimepicker2").val();
    cita.hora = $("#nuevaCita_hora").val();
    cita.paciente = $("#id_paciente").val();
    cita.accion = 'insertar';

    console.log(cita);

    respuesta=enviarJSON('../php/insertarCita.php',cita); 

    respuesta.done(function(data,textStatus,jqXHR){

        if(data.error)  {

            $('#error_calendario').removeClass('alert-success');
            $('#error_calendario').addClass('alert-danger');
        } else {

            $('#error_calendario').removeClass('alert-danger');
            $('#error_calendario').addClass('alert-success');
			cargarHoras();
        }

        $('#error_calendario > span').text(data.descripcion);
        $('#error_calendario').show('slow');
    });        
    
}

/**
 * cargarEspecialidad - consulta en la BD las posibles especialidades.
 */
function cargarPaciente(){
    
    var respuesta = {};
    var peticion = {};
    var html = '';

    peticion.accion = "consultar";
    peticion.opcion = "paciente";

    respuesta = enviarJSON('../php/listarPaciente.php', peticion);

    respuesta.done(function( data, textStatus, jqXHR ) {

        html += '<option value="">Selecionar ...</option>';

        $.each( data, function( key, value ) {

            html += '<option value="' + value.id + '">';
            html += value.apellidos+", "+value.nombre;
            html += '</option>';
        });

        $('#listarPacientes > select').html(html);
    });
}
/*
* funcion cargarEspecialidad, obtiene las especialidades de la cl�nica y las carga en el formulario.
*/

function cargarEspecialidad() {

	var respuesta = {};
	var peticion = {};
	var html = '';

	peticion.accion = "consultar";
	peticion.opcion = "especialidad";

	respuesta = enviarJSON('../php/insertarPersonal.php', peticion);

	respuesta.done(function (data, textStatus, jqXHR) {

		html += '<option value="">Selecionar ...</option>';

		$.each(data, function (key, value) {
			$('#nuevaCita_especialidad').append('<option value="' + value.id + '">' + value.nombre + '</option>');
		});
	});
}