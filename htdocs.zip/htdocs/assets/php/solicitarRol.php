<?php
/*Devuelve el rol del usuario conectado. Si no hay sesi�n activa devuelve "DESCONECTADO"*/

$response = array();
if(isset( $_SESSION['perfil'] )){
	$response['rol'] = $_SESSION['perfil'];
}else{
	$response['rol'] ="DESCONECTADO";
}

echo json_encode($response);