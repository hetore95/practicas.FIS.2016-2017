<?php

require '../php/BBDD.php';

$obj = json_decode($_POST['json'], true);
//DELETE FROM `salas` WHERE `FECHA`= '2017-05-30'
//$obj['fecha'] = '2017-05-30'; 
$sala = 1;
$error = "";
$response = array();
$link = conectar();

if ($obj['fecha']=="") {
	$error = "Campo fecha no definido";
}
if( $error != "" ) {

			$response['error'] = true;
			$response['descripcion'] = $error;

} else{
		//Limpiar día
		$sql ="DELETE FROM programacion_salas WHERE fecha = '".$obj['fecha']."'";
		mysql_query($sql, $link);	

		//Pedir especialidades
		$especialidades = consulta("id","especialidad");
		$iEspecialidad = rand(0,count($especialidades));
		
		//Asignar doctor, especialidad y sala
		for($i = 0; $i <count($especialidades); $i++){
			if( $iEspecialidad >=  count($especialidades)){
				$iEspecialidad = 0;
			}
			
			//echo "</br></br>___________________________</br>ASIGNANDO ESPECIALIDAD ".$especialidades[$iEspecialidad]."</br>";
			
			$sql = "SELECT ID_PERSONAL
					FROM rel_personal_especialidad 
					WHERE ID_ESPECIALIDAD = '".$especialidades[$iEspecialidad]."'";
	
			$result = mysql_query($sql, $link);		
			
			//Buscar un médico libre para asignar
			$encontrado = false;
			$l = 0;
			while(($row = mysql_fetch_row($result)) && !$encontrado){
				/*echo "</br>";
				echo "ROW ";*/
				//print_r($row);
				$sql = "SELECT ID FROM programacion_salas WHERE ID_PERSONAL= ".$row[0]." AND FECHA = '".$obj['fecha']."'" ;
				//	echo "</br>";
				$result2 = mysql_query($sql, $link);
				if(mysql_num_rows($result2) == 0){
					$id = $row[0];
					//echo "personal:";
					//echo $row[0];
					$encontrado = true;
				}
				//echo "</br>FIN DE VUELTA ".$l."</br>";
				$l++;
			}
			
			if($encontrado){			
				$sql = "INSERT INTO programacion_salas VALUES ('','". $sala."' ,'".$especialidades[$iEspecialidad]."','".$id."','".$obj['fecha']."')";
				//echo '</br>INSERTAR: '.$sql;
				$result = mysql_query($sql, $link);
				$response['error'] = true;
				
				/*echo "especialidad:";
			echo $especialidades[$iEspecialidad];
			echo ",		";*/
			}
			
			$response['descripcion'] = "Informacion actualizada";
			$response['error'] = false;
			$sala++;
			$iEspecialidad++;
		}
}

	mysql_close($link);



echo json_encode($response);

?> 