<?php

require '../php/BBDD.php';

//$obj = json_decode($_POST['json'], true);

$obj['numSala'] ="1";
$obj['fecha'] = '2017-05-14';
$error = "";
$response = array();
$id_registro = 0;

// VALIDACI�N
//CONEXI�N A LA BBDD
$link = conectar();


$sql = "SELECT ID FROM programacion_salas WHERE ID_SALA = '" . $obj['numSala'] . "'";
$result = mysql_query($sql, $link);

if (mysql_num_rows($result) > 0) {

    $sql = "SELECT ID_ESPECIALIDAD, ID_PERSONAL FROM programacion_salas WHERE ID_SALA = '". $obj['numSala']."' AND FECHA = '".$obj['fecha']."'";
    $result = mysql_query($sql, $link);

    if (mysql_num_rows($result) > 0) {
        //Sacar citas y buscar el resto de datos
		$i = 0;
		$salas = array();
		$row = mysql_fetch_row($result);

			//Buscar especialidad
		$sql = "SELECT nombre FROM especialidad WHERE id = ".$row[0];
        $row_2 = mysql_fetch_assoc(mysql_query($sql, $link));
        $espec = $row_2['nombre'];
			
            //Buscar m�dico
        $sql = "SELECT id_usuario FROM PERSONAL WHERE id = ".$row[1];
        $id = mysql_fetch_assoc(mysql_query($sql, $link))['id_usuario'];
        $sql = "SELECT nombre, apellidos FROM USUARIO WHERE id = ".$id;
        $row_2 = mysql_fetch_assoc(mysql_query($sql, $link));
        $medico = $row_2['apellidos'].', '.$row_2['nombre'];
            

		$response['especialidad'] = $espec;
		$response['medico'] = $medico;
                 
    } else {
		$response['error'] = true;
		$response['descripcion'] = "No hay salas";
    }
} else {
		$response['error'] = true;
		$response['descripcion'] = "No existe sala";
}
echo $response['especialidad'], $response['medico'];

//RESPUESTA
echo json_encode($response);      
?>