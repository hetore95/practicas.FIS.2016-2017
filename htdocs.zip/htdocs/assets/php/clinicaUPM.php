<?php

	// FLUJO
	$peticion = json_decode($_POST['json'], true);
	//$peticion = $_POST;
	if( isset( $peticion['accion'] ) && isset( $peticion['opcion'] ) ){
		if($peticion['opcion'] == 'sesion'){
			
		}
		if( $peticion['opcion'] == 'sesion' ){
			session_start();
			
			if( $peticion['accion'] == 'consultar' ){echo json_encode($_SESSION); }

			elseif( $peticion['accion'] == 'cerrar' ){session_destroy(); echo json_encode($_SESSION);}
		}
	}
	
	// FIN FLUJO



	// Inicia una sesión PHP y se queda con el usuario que accede al sistema
	function iniciarSesion( $usuario, $perfil, $id ){

		session_start();

		$_SESSION['id'] = $id;
		$_SESSION['usuario'] = $usuario;
		$_SESSION['perfil'] = $perfil;
	}
?>