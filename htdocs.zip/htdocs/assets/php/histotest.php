<?php
include 'BBDD.php';
class Historial {	
    var $fecha;
    var $comentario;

    function __construct($fecha, $comentario) {
       $this->fecha = $fecha;
       $this->comentario = $comentario;
    }
}

$obj = json_decode($_POST['json'], true);

//Buscar historial
$sql = "SELECT f_alta,comentarios FROM historial WHERE id_paciente = ".$obj['id_paciente']." ORDER BY f_alta DESC";
$response = consulta('f_alta,comentarios','historial','',$sql);
$respuesta['historial']= $response;
//Buscar paciente
$response = consulta('id_usuario','paciente','id = '.$obj['id_paciente']);
$response = consulta('nombre, apellidos','usuario','id = '.$response);
$respuesta["nombre_paciente"] = $response[0]['nombre'].' '.$response[0]['apellidos'];	

$myJSON = json_encode($respuesta);
echo $myJSON;
?>