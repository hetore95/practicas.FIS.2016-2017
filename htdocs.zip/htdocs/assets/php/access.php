<?php
/**Si no hay sesi�n inciada redirige al �ndice, si la hay, comprueba
si es un m�dico solicitando una p�gina que requiere permisos de administrador,
en cuyo caso redirige a un mensaje de error. En otro caso, devuelve la p�gina solicitada. **/
							
	$paginasAdmin = array("/assets/html/nuevoPaciente.html",
						"/assets/html/insertarCita.html",
						"/assets/html/nuevoPaciente.html",
						"/assets/html/nuevoPersonal.html",
						"/assets/php/insertarCita.php",
						"/assets/php/insertarPaciente.php",
						"/assets/php/calendario.html");
session_start();
if(isset( $_SESSION['perfil'] ) ) {
	if($_SESSION['perfil'] == 'PERSONAL' && in_array($_SERVER['REQUEST_URI'], $paginasAdmin)){
		$url = '../php/error.php';
		$_SESSION['errorMsg'] = utf8_encode("No se tienen permisos para entrar a la p�gina solicitada.");
		header("Location: ".$url);		
	} else{
		$url = parse_url($_SERVER['REQUEST_URI']);
		//TODO: Pasar par�metros GET
		
		include("../..".$url['path']);
	}
}else{
	$url = '../../index.html';
	header("Location: ".$url);
	die();
}
