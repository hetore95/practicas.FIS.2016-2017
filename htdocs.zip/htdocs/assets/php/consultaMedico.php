<?php

  require 'BBDD.php';

  //var_dump($_POST);

  $obj = json_decode($_POST['json'], true);
  $response = array();
  $i = 0;

  //var_dump($obj);
  $link = conectar();

  // Para que la respuesta pueda contener acentos
  mysql_set_charset("utf8", $link);

  $sql = "SELECT ID_PERSONAL FROM rel_personal_especialidad where ID_ESPECIALIDAD = '" . $obj['id'] . "'";
  $result = mysql_query($sql, $link);


    if( mysql_num_rows($result) > 0 ) {

		while( $fila = mysql_fetch_assoc($result) ) {
	      // Para que la respuesta pueda contener acentos
	      mysql_set_charset("utf8", $link);

	      $sql = "SELECT personal.ID, concat(usuario.APELLIDOS, ', ', usuario.NOMBRE) as nombreMedico FROM personal, usuario WHERE personal.ID = '".$fila['ID_PERSONAL']."' AND  personal.ID_USUARIO = usuario.ID";
		  $result1 = mysql_query($sql, $link);
		  $row = mysql_fetch_assoc($result1);
          $response[$i]['ID'] = $row['ID'];
          $response[$i]['NOMBRE'] = $row['nombreMedico'];

          $i++; 
      }
	
  }
  echo json_encode($response);
?>