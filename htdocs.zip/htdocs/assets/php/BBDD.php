<?php

	function conectar(){

		// Se conecta a la bbbd y devuelve un identificador de conexión

		$servername  = "localhost";
		$db_username = "root";
		$db_password = "";
		$db_name     = "clinica_upm";

		$conn = mysql_connect($servername, $db_username, $db_password);

		if (!$conn) {
		    die('No se pudo conectar al servidor: ' . mysql_error());
		}

		$select_db = mysql_select_db($db_name, $conn);

		if (!$select_db) {
		    die('No se pudo conectar a la base de datos.');
		}

		//console_log("CONECTADO A LA BBDD");

		return $conn;
	}


	function consulta( $campos, $tabla, $condicion = '', $sql = '' ){

		$link = conectar();

		$campos = strtolower(str_replace(' ', '', $campos));
		$arr_campos = explode(",", $campos);
		$response = array();
		$i = 0;

		mysql_set_charset("utf8", $link);

		if( $sql == '' ){

			if( $condicion != '' )
				$condicion = ' WHERE ' . $condicion;
		
      		$sql = 'SELECT ' . $campos . ' FROM ' . $tabla . $condicion;
		}

      	$result = mysql_query($sql, $link);

      	if( count($arr_campos) != 1 ){

      		while( $fila = mysql_fetch_assoc($result) ) {

	      		array_push($response, $fila);
	      	}
	      	
      	} else {

      		if( mysql_num_rows($result) == 1 ){

      			$fila = mysql_fetch_assoc($result);

      			return $fila[$arr_campos[0]];

      		} else {

      			while( $fila = mysql_fetch_assoc($result) ) {

	      			$response[$i] = $fila[$arr_campos[0]];

	      			$i++;
		      	}
      		}
      	}

      	return $response;
	}

?>