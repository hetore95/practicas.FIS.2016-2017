<?php
require '../php/BBDD.php';


$obj = json_decode($_POST['json'], true);
$error = "";
$respuesta = array();
$id_registro = 0;


//ELECCI�N DE ACCI�N
if ($obj['accion'] == 'consultar') {
	/********CONSULTA DE CITAS*********/
    if ($obj['opcion'] == 'citas') {
        //SELECCI�N DE CITAS
        //Conexi�n a BBDD
        $link = conectar();
        mysql_set_charset("utf8", $link);

        //Buscar especialidad
        $sql = "SELECT id, nombre FROM especialidad WHERE id = '" . $obj['id'] . "'";
        $result = mysql_query($sql, $link);
		
        if (mysql_num_rows($result) > 0) {
            //Buscar citas
            $row = mysql_fetch_row($result);
			$respuesta['especialidad'] = $row[1];
            $sql = "SELECT DATE_FORMAT(fecha,GET_FORMAT(DATE,'EUR')),DATE_FORMAT(fecha,GET_FORMAT(TIME,'EUR')), id_personal, id_paciente FROM cita WHERE id_especialidad = '" . $row[0] . "' AND fecha BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 WEEK) ORDER BY fecha ";
            $result = mysql_query($sql, $link);

            if (mysql_num_rows($result) > 0) {
                //Sacar citas y buscar el resto de datos
                $i = 0;
                $citas = array();
                while ($row2 = mysql_fetch_row($result)) {

                    //Buscar m�dico y sala{
                        $sql = "SELECT id_usuario FROM PERSONAL WHERE id = " . $row2[2];
                        $id = mysql_fetch_assoc(mysql_query($sql, $link))['id_usuario'];
                        $sql = "SELECT nombre, apellidos FROM USUARIO WHERE id = " . $id;
                        $row_2 = mysql_fetch_assoc(mysql_query($sql, $link));
                        $medico = $row_2['nombre'] . ' ' . $row_2['apellidos'];
                        
						$sql = "SELECT  id_sala FROM PROGRAMACION_SALAS WHERE id_especialidad = " . $row[0]. " AND DATE_FORMAT(fecha,GET_FORMAT(DATE,'EUR')) = '".$row2[0]."'";
						$sala = mysql_fetch_assoc(mysql_query($sql, $link))['id_sala'];
                    
                    
                    //Buscar paciente
                    $sql = "SELECT id_usuario FROM PACIENTE WHERE id = " . $row2[3];
                    $id = mysql_fetch_assoc(mysql_query($sql, $link))['id_usuario'];
                    $sql = "SELECT nombre, apellidos FROM USUARIO WHERE id = " . $id;
                    $row_2 = mysql_fetch_assoc(mysql_query($sql, $link));
                    $paciente = $row_2['nombre'] . ' ' . $row_2['apellidos'];

                    $citas[$i] = array('fecha' => $row2[0],
                        'hora' => $row2[1],
                        'paciente' => $paciente,
						'medico' => $medico,
						'sala' => $sala);

                    $i++;
                }
                $respuesta['citas'] = $citas;
                $respuesta['error'] = false;
            } else {
                $respuesta['error'] = true;
                $respuesta['descripcion'] = "No hay citas";
            }
        } else {
            $respuesta['error'] = true;
            $respuesta['descripcion'] = "No existe especialidad";
        }
	/********CALENDARIO DIARIO*********/
    } else if($obj['opcion'] == 'calendarioDiario'){
		//Comprobar que el usuario conectado es un m�dico
		if(isset($_SESSION['perfil']) && $_SESSION['perfil'] == 'PERSONAL'){
			//Conexi�n a BBDD
			$link = conectar();
			mysql_set_charset("utf8", $link);
			
			//Buscar m�dico 
			$sql = "SELECT nombre, apellidos FROM usuario WHERE id = '" . $_SESSION['id'] . "'";
			$result = mysql_query($sql, $link);
			
			 if (mysql_num_rows($result) > 0) {	

				$row = mysql_fetch_assoc($result);	
				$respuesta['medico'] = $row['nombre'].' '.$row['apellidos'];
				$sql = "SELECT id FROM personal WHERE id_usuario = '" . $_SESSION['id'] . "'";
				$result = mysql_query($sql, $link);
				
				//Buscar id del m�dico
                $citas = array();
				$id =  mysql_fetch_assoc(mysql_query($sql, $link))['id'];
				$respuesta['idMedico'] = $id;
				
				//Buscar citas de hoy del m�dico
				$sql = "SELECT DATE_FORMAT(fecha,GET_FORMAT(TIME,'EUR')), id_paciente FROM cita WHERE id_personal = '" . $id . "' AND DATE(fecha) = CURDATE() ORDER BY fecha ";
				$result = mysql_query($sql, $link);
				
                $i = 0;
				if (mysql_num_rows($result) > 0) {
					while ($row = mysql_fetch_row($result)) {
						//Buscar paciente
						$idUsuario = $row[1];
						$sql = "SELECT id_usuario FROM PACIENTE WHERE id = " . $idUsuario;
						$id = mysql_fetch_assoc(mysql_query($sql, $link))['id_usuario'];
						$sql = "SELECT nombre, apellidos FROM USUARIO WHERE id = " . $id;
						$row2 = mysql_fetch_assoc(mysql_query($sql, $link));
						$paciente = $row2['nombre'] . ' ' . $row2['apellidos'];
						
						$citas[$i] = array('hora' => $row[0],
                        'paciente' => $paciente,
						'idPaciente' => $idUsuario);

						$i++;
					}
				}
                $respuesta['citas'] = $citas;
				$respuesta['dia'] = date("d/m/Y");
                $respuesta['error'] = false;
				
			 }else{
				$respuesta['error'] = true;
				$respuesta['descripcion'] = utf8_encode("Error: No se ha encontrado el m�dico conectado en la Base de Datos.");
			 }
			
		}else{
			$respuesta['error'] = true;
			$respuesta['descripcion'] = utf8_encode("Error: El usuario conectado no es un m�dico.");
		}			
	
	/********ESPECIALIDADES*********/
	}else if ($obj['opcion'] == 'especialidades') {
        //SELECCI�N DE ESPECIALIDADES
        //Conexi�n a BBDD
        $link = conectar();
        mysql_set_charset("utf8", $link);
        $sql = "SELECT DISTINCT ID_ESPECIALIDAD FROM cita WHERE fecha BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 WEEK) ORDER BY fecha";
        $result = mysql_query($sql, $link);

        if (mysql_num_rows($result) > 0) {
            //Sacar citas y buscar el resto de datos
            $especialidades = array();
            $i = 0;
            while ($row = mysql_fetch_row($result)) {
                $sql = "SELECT ID, NOMBRE FROM especialidad WHERE id = " . $row[0];
                $result2 = mysql_query($sql, $link);
                $fila = mysql_fetch_assoc($result2);
                $especialidades[$i]['ID'] = $fila['ID'];
                $especialidades[$i]['NOMBRE'] = $fila['NOMBRE'];
                $i++;
            }
            $respuesta['especialidades'] = $especialidades;
            $respuesta['error'] = false;
        } else {
            $respuesta['error'] = true;
            $respuesta['descripcion'] = "No hay citas";
        }
    } else {
        $respuesta['error'] = true;
        $respuesta['descripcion'] = utf8_encode("Opci�n de acci�n no indicada.");
    }
} else {
    $respuesta['error'] = true;
    $respuesta['descripcion'] = utf8_encode("Acci�n no indicada.");
}
//RESPUESTA
echo json_encode($respuesta);
