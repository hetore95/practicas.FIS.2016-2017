<?php

require '../php/BBDD.php';
$obj = json_decode($_POST['json'], true);

$error = "";
$response = array();


if ($obj['especialidad']=="") {
	$error = "Campo especialidad no definido";
}
elseif ($obj['fecha']=="") {
	$error = "Campo fecha no definido";
}
elseif ($obj['personal']=="") {
	$error = "Campo personal definido";
}
elseif ($obj['numSala']=="" || 0 > $obj['numSala'] ||  10 < $obj['numSala']) {
	$error = "Error en campo de sala";
}
//COMPROBACI�N DE DATOS CON LA BBDD
else{
	//Comprobar si el m�dico est� libre
	$link = conectar();
	$sql = "SELECT ID FROM programacion_salas WHERE ID_PERSONAL= ".$obj['personal']." AND FECHA = '".$obj['fecha']."'";
	$result = mysql_query($sql, $link);
	if(mysql_num_rows($result) != 0){
		$error = "Doctor ya asignado.";
	}
	//Comprobar si la especialidad no est� asignada
	else{
		$sql = "SELECT ID FROM programacion_salas WHERE ID_ESPECIALIDAD= ".$obj['especialidad']." AND FECHA = '".$obj['fecha']."'" ;
		$result = mysql_query($sql, $link);
		if(mysql_num_rows($result) != 0){
			$error = "Especialidad ya asignada.";
		}
	}
	mysql_close($link);
}

if( $error != "" ) {

			$response['error'] = true;
			$response['descripcion'] = $error;

} else{	
		$link = conectar();

			$sql = "SELECT id FROM programacion_salas WHERE FECHA = '".$obj['fecha']."' AND ID_SALA = ".$obj['numSala'];
			$result = mysql_query($sql, $link);
	
			if(mysql_num_rows($result) == 0){

				$sql = "INSERT INTO programacion_salas VALUES ('','". $obj['numSala']."' ,'".$obj['especialidad']."','".$obj['personal']."','".$obj['fecha']."')";
	
				$result = mysql_query($sql, $link);

				$response['error'] = false;
				$response['descripcion'] = "Informacion actualizada";
				
			}else{
				
				$sql = "UPDATE programacion_salas 
						SET programacion_salas.ID_PERSONAL = '".$obj['personal']."', programacion_salas.ID_ESPECIALIDAD = '".$obj['especialidad']."'  
  						WHERE ID_SALA  = '". $obj['numSala']."' AND FECHA = '".$obj['fecha']."'";
	
				$result = mysql_query($sql, $link);

				$response['error'] = false;
				$response['descripcion'] = "Informacion actualizada";
			}

	mysql_close($link);
}


echo json_encode($response);

?> 