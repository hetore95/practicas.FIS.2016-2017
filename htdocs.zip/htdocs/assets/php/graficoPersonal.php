<?php

  require 'BBDD.php';

  function generarGraficoBarras( $especialidad ){

    $dataset = array();

    $id_especialidad = (int) consulta('id', 'especialidad', 'nombre = "' . $especialidad . '"');

    $ids_personal = consulta('id_personal', 'rel_personal_especialidad', 'id_especialidad = ' . $id_especialidad);

    for($i=0; $i<count($ids_personal); $i++){

      $id_usuario = consulta('id_usuario', 'personal', 'id = ' . $ids_personal[$i]);

      $apellidos = consulta('apellidos', 'usuario', 'id = ' . $id_usuario);
      $nombre = consulta('nombre', 'usuario', 'id = ' . $id_usuario);

      $dataset[$i]['nombre'] = $apellidos . ', ' . $nombre;

      $sql = 'SELECT MONTH(C.FECHA) AS MES, COUNT(C.ID) AS NUM_CITAS
              FROM cita C
              INNER JOIN especialidad E ON C.id_especialidad = E.id
              WHERE YEAR(C.fecha) = YEAR(CURDATE())
              AND C.id_especialidad = ' . $id_especialidad . '
              AND C.id_personal = ' . $ids_personal[$i] . ' 
              GROUP BY MONTH(C.FECHA)';

      $citas_por_mes = consulta( 'MES, NUM_CITAS', '', '', $sql );

      for($j=0; $j<12; $j++)
        $num_citas[$j] = 0;

      for($j=0; $j<count($citas_por_mes); $j++){

        // Cuando un médico no ha tenido citas de esa especialidad
        if( count($citas_por_mes[$j]) != 0 ){

          $num_citas[$citas_por_mes[$j]['MES']] = (int) $citas_por_mes[$j]['NUM_CITAS'];
        }
      }

      $dataset[$i]['num_citas'] = $num_citas;
    }

    return $dataset;    
  }


  function generarGraficoQueso(){

    $sql = 'SELECT E.nombre AS especialidad, COUNT(C.ID) AS num_citas
            FROM cita C
            INNER JOIN especialidad E ON C.id_especialidad = E.id
            WHERE YEAR(C.fecha) = YEAR(CURDATE())
            GROUP BY C.id_especialidad';

    return consulta( 'especialidad, num_citas', '', '', $sql );
  }

?>