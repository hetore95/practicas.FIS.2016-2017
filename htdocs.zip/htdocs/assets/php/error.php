<!doctype html>
<html lang="es">

    <head>
        <meta charset="utf-8" />
        <link rel="icon" type="image/png" href="../img/favicon.png">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

        <title>Clínica UPM - Error</title>

        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />

        <!-- Bootstrap core CSS     -->
        <link href="../css/bootstrap.min.css" rel="stylesheet" />

        <!-- Animation library for notifications   -->
        <link href="../css/animate.min.css" rel="stylesheet" />

        <!--  Light Bootstrap Table core CSS    -->
        <link href="../css/light-bootstrap-dashboard.css" rel="stylesheet" />

        <!--     Fonts and icons     -->
        <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
        <link href="../css/pe-icon-7-stroke.css" rel="stylesheet" />

        <!-- CSS hecho por nosotros -->
        <link href="../css/clinica_upm/clinicaUPM.css" rel="stylesheet" />

        <!-- datetimepicker -->
        <link rel="stylesheet" type="text/css" href="../jquery/datetimepicker/jquery.datetimepicker.css"/>

    </head>

    <body>
        <!-- <form action="../php/insertarCita.php" method="POST"> -->
        <div class="wrapper">
            <div id="menuPrincipal">
                <!-- Aquí va el menú de la app -->
            </div>

            <div class="main-panel">
                <div id="barraNavegacion">
                    <!-- Aquí va la barra de navegación de la app -->
                </div>

                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="header">
                                        <h4 class="title">ERROR</h4>
                                    </div>
                                    <div class="content">
                                       <?php
									   if(isset($_SESSION['errorMsg'])){
										   echo '<span style="color:#dd5050">'.$_SESSION['errorMsg'].'</span>';
									   }
									   ?>
									 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>

    <!--   Core JS Files   -->
    <script src="../js/jquery-1.10.2.js" type="text/javascript"></script>
    <script src="../js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Checkbox, Radio & Switch Plugins -->
    <script src="../js/bootstrap-checkbox-radio-switch.js"></script>

    <!--  Charts Plugin -->
    <script src="../js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="../js/light-bootstrap-dashboard.js"></script>

    <!-- FIS -->
    <script src="../js/clinica_upm/clinicaUPM.js"></script>
    <script src="../js/clinica_upm/cita.js"></script>

    <!-- datetimepicker -->
    <script src="../jquery/datetimepicker/jquery.js"></script>
    <script src="../jquery/datetimepicker/build/jquery.datetimepicker.full.js"></script>

    <script type="text/javascript">     				
		$(document).ready(function () {

			pintarMenu('', 'red');
			pintarBarraNavegacion();

			$('h4.title').css('color', 'red');
			$('h4.title').css('border-bottom', '1px solid');
			
		
		});		
    </script>

</html>