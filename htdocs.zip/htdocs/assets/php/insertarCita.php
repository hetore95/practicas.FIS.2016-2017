<?php

require 'BBDD.php';

//var_dump($_POST);

$obj = json_decode($_POST['json'], true);

//var_dump($obj);

$error = "";
$response = array();
$id_registro = 0;

if ($obj['accion'] == 'insertar') {
// VALIDACIÓN DEL FORMULARIO
//comprobamos que el formulario está completo(campo por campo)
    if ($obj['especialidad'] == "") {
        $error = "Campo especialidad no definido";
    } elseif ($obj['fecha'] == "" || $obj['hora'] == "no") {
        $error = "Campo fecha no definido";
    } elseif ($obj['hora'] == "") {
        $error = "Campo hora no definido";
    } elseif ($obj['paciente'] == "") {
        $error = "Campo paciente no definido";
    }

// si hay errores, no se sigue y se informa
    if ($error != "") {

        $response['error'] = true;
        $response['descripcion'] = $error;
    } else {

// CONEXIÓN A LA BBDD
        $link = conectar();

//Obtener el id_especialidad
        $sql = "SELECT id FROM especialidad WHERE id = '" . $obj['especialidad'] . "'";
        $result = mysql_query($sql, $link);
        $fila = mysql_fetch_assoc($result);

        if ($fila['id'] != 0) {

            $especialidad = $obj['especialidad'];
            $calendario = $obj['fecha'] . ' ' . $obj['hora'];

            $sql = "SELECT id FROM cita  WHERE fecha LIKE '" . $calendario . "' AND id_especialidad = " . $fila['id'];

            $result = mysql_query($sql, $link);

            if (mysql_num_rows($result) == 0) {

//Subconsulta de usuario
                $subconsulta = "(SELECT id FROM paciente WHERE id_usuario = " . $obj['paciente'] . ")";

//Subconsulta de médico
				$subconsulta2 = "(SELECT id_personal FROM programacion_salas WHERE id_especialidad = ".$obj['especialidad']." AND fecha = '".date($obj['fecha'])."')";
//Ingresar la informacion a la tabla de datos
                $sql = "INSERT INTO cita VALUES ('','" . $calendario . "'," . $fila['id'] . ",".$subconsulta2.", " . $subconsulta . ")";	
				$result = mysql_query($sql, $link);

// Si se ha insertado correctamente en CITA
                if ($result) {
                    $response['error'] = false;
                    $response['descripcion'] = "Petición de cita realizada";
                } else {
                    $response['error'] = true;
                    $response['descripcion'] = "No se ha podido insertar en la tabla cita";
                }
            } else {
                $response['error'] = true;
                $response['descripcion'] = "La cita seleccionada no está disponible, seleccione otra cita.";
            }
        } else {
            $response['error'] = true;
            $response['descripcion'] = "Especialidad no disponible";
        }
    }
} else if ($obj['accion'] == 'pedirHoras') {
    //Validaci�n de datos

    if ($obj['especialidad'] == "") {
        $error = "Campo especialidad no definido";
    } elseif ($obj['fecha'] == "") {
        $error = "Campo fecha no definido";
    }

    //Si hay errores, se devuelve. Si no, se contin�a con la solicitud.
    if ($error != "") {
        $response['error'] = true;
        $response['descripcion'] = $error;
    } else {
        // CONEXIÓN A LA BBDD
        $link = conectar();
        
        
        //Pedir sala, médico asignado y el tiempo de consulta al d�a y a la especialidad proporcionadas
        $sql = "SELECT 	ID_SALA, ID_PERSONAL FROM programacion_salas WHERE id_especialidad = ".$obj['especialidad']." AND fecha = '".$obj['fecha']."'";
		$result = mysql_query($sql, $link);
		
		if(mysql_num_rows($result) > 0) {
			$fila = mysql_fetch_assoc($result);
			$response['sala'] = $fila['ID_SALA'];
			
			$sql = "SELECT id_usuario,tiempo_min_consulta FROM personal WHERE id = ".$fila['ID_PERSONAL'];
			$result = mysql_query($sql, $link);
			$fila = mysql_fetch_assoc($result);
			$response['tiempoConsulta'] = $fila['tiempo_min_consulta'];
			
			$sql = "SELECT nombre, apellidos FROM usuario WHERE id = ".$fila['id_usuario'];
			$result = mysql_query($sql, $link);
			$fila = mysql_fetch_assoc($result);
			$response['medico'] = $fila['nombre'].' '.$fila['apellidos'];			
			
			//Pedir horas ocupadas en el d�a y especialidad proporcionados
			$horas = array();

			$sql = "SELECT DATE_FORMAT(fecha,GET_FORMAT(TIME,'EUR'))FROM cita WHERE id_especialidad = '" . $obj['especialidad'] . "' AND DATE(fecha) = '" . $obj['fecha']."'";
			$result = mysql_query($sql, $link);

			if (mysql_num_rows($result) > 0) {
				$i = 0;
				$citas = array();
				while ($row = mysql_fetch_row($result)) {
					$horas[$i]=$row[0];
					$i++;
				}
			}

			//Agregar datos a la respuesta
			$response['error'] = false;
			$response['horas'] = $horas;
		}else{
			$response['error'] = true;
			$response['descripcion'] = "No hay doctor asignado a la especialidad requerida.";			
		}
	}
    } else {
        $response['error'] = true;
        $response['descripcion'] = "Acci�n no indicada.";
    }
    echo json_encode($response);
?>