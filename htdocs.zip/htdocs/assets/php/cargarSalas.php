<?php

require '../php/BBDD.php';

$respuesta = consulta("id_sala, id_especialidad, id_personal, fecha","programacion_salas","fecha BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 WEEK) ORDER BY fecha");

for($i = 0; $i< sizeof($respuesta);$i++){
	$id = consulta("id_usuario","personal","id = ".$respuesta[$i]['id_personal']);
	$r2 = consulta("nombre, apellidos","usuario","id = ".$id);
	$respuesta[$i]['personal'] = $r2[0]["nombre"].' '.$r2[0]["apellidos"];

	$respuesta[$i]['especialidad'] = consulta("nombre","especialidad","id = ".$respuesta[$i]['id_especialidad']);
}

echo json_encode($respuesta);

?>
