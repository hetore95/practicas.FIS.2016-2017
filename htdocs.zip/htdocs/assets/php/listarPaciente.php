<?php
	require 'BBDD.php';
	//var_dump($_POST);
	
	$obj = json_decode($_POST['json'], true);
	//print_r( $obj);
	$i = 0;

	//var_dump($obj);

	$error = "";
	$response = array();

	//$link = conectar();

	if( $obj['accion'] == 'consultar' ) {

    	if( $obj['opcion'] == 'paciente' ) {
			
			$response = consulta('id, apellidos, nombre', 'usuario', "TIPO_USUARIO = 'PACIENTE'");
    	}
    }

    echo json_encode($response);
?>