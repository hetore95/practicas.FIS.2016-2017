# Objetos JSON

## Envio de Forms.

### Nuevo Personal

```
{
    "nombre" :"Pepe",
    "apellido":"Marin",
    "numColegiado":"1234",
    "tMinConsulta":"1",
    "diasConsulta":"3",
    "especialidad":[
        "Podologo",
        "..."
    ]
}
```

### Nuevo Paciente

```
{
    "nombre":"Pepe",
    "apellido":"Marin",
    "companyia":"asdf",
    "dni":"123456789"
}
```

### Loggin

```
{
    "usr" : "1234567890",
    "passwd" : "asdf"
}
```